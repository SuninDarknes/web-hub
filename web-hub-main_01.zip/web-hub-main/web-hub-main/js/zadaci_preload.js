$(function(){
    $("#LV01").load("files/zadaci/LV01.html");
    $("#LV07").load("files/zadaci/LV07.html");
  });